double chi2(double m, double b, double *x, double *y, double *yerr, int N);


//num = _chi2.chi2(2.0, 1.0, [-1.0, 4.2, 30.6], [-1.5, 8.0, 63.0],[1.0, 1.5, 0.6])
//var = str(num)
